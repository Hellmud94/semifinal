package com.project.semi.employee.service;

public class EmployeeServiceImpl implements EmployeeService {

}
