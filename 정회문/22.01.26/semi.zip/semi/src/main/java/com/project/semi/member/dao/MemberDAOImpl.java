package com.project.semi.member.dao;

public class MemberDAOImpl implements MemberDAO {

}
