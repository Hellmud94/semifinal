package com.project.semi.admin.service;

public class AdminServiceImpl implements AdminService {

}
