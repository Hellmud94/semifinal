package com.project.semi.member.service;

public class MemberServiceImpl implements MemberService {

}
