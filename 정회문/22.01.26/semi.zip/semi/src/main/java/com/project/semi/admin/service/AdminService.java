package com.project.semi.admin.service;

public interface AdminService {

}
