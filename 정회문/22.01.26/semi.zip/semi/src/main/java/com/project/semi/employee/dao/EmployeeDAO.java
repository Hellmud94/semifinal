package com.project.semi.employee.dao;

public interface EmployeeDAO {

}
