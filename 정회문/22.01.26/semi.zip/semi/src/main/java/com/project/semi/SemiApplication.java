package com.project.semi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SemiApplication {

	public static void main(String[] args) {
		System.out.println("Run");
		SpringApplication.run(SemiApplication.class, args);
	}

}
