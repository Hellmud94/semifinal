package com.project.semi.employee.service;

public interface EmployeeService {

}
