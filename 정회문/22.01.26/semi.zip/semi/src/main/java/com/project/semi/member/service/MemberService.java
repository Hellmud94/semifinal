package com.project.semi.member.service;

public interface MemberService {

}
