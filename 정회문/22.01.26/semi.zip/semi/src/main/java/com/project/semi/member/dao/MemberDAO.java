package com.project.semi.member.dao;

public interface MemberDAO {

}
