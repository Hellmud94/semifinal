package com.project.semi.admin.dao;

public class AdminDAOImpl {

}
