package com.project.semi.employee.dao;

public class EmployeeDAOImpl implements EmployeeDAO {

}
